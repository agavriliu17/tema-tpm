package org.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        int nrOfThreads = 4;
        List<Lock> myLocks = new ArrayList<>();
        myLocks.add(new ShadyLock());
        for(Lock lock: myLocks){
            int[] threadAccess = new int[nrOfThreads];
            Contor contor = new Contor();
            List<Thread> threads = new ArrayList<>();

            for (int i = 0; i < nrOfThreads; i++) {
                threads.add(new ContorIncrementorThread(contor, threadAccess, i, lock));
            }

            long startTime = System.nanoTime();

            for (Thread thread : threads){
                thread.start();
            }
            for (Thread thread : threads){
                thread.join();
            }
            long endTime = System.nanoTime();

            System.out.println("Time ms: " + (endTime - startTime)/1000000);
            System.out.println("Valoare contor: " + contor.x);
            System.out.println("Nr of accesses per thread:");
            for (int i = 0; i < nrOfThreads; i++) {
                System.out.println( i + "\t" + threadAccess[i]);
            }

            System.out.println("Total acceses per threads: " + Arrays.stream(threadAccess).sum());
        }
    }
}