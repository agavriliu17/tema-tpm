package org.internal;

public class ContorIncrementorThread extends Thread {
    private final Contor contor;
    private final int[] accessTable;
    private final int threadIndex;
    private final MyLock lock;

    public ContorIncrementorThread(Contor contor, int[] accessTable, int threadIndex, MyLock lock){
        this.contor = contor;
        this.accessTable = accessTable;
        this.threadIndex = threadIndex;
        this.lock = lock;
    }
    @Override
    public void run(){
        while(true){
            lock.lock(threadIndex);
            if(contor.x >= 400000){
                lock.unlock(threadIndex);
                break;
            }
            contor.x += 1;
            lock.unlock(threadIndex);
            this.accessTable[threadIndex] += 1;
        }
    }
}
