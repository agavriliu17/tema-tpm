package org.internal;

import java.util.concurrent.atomic.AtomicInteger;

public class FairPetersonLock implements MyLock{
    private int n;
    private volatile AtomicInteger[] level;
    private volatile AtomicInteger[] victim;

    private volatile AtomicInteger[] accesses;

    public FairPetersonLock(int n){
        this.n = n;
        this.level = new AtomicInteger[n];
        for (int i = 0; i < n; i++) {
            level[i] = new AtomicInteger();
            level[i].set(0);
        }
        this.victim = new AtomicInteger[n];
        for (int i = 0; i < n; i++) {
            victim[i] = new AtomicInteger();
            victim[i].set(0);
        }
        this.accesses = new AtomicInteger[n];
        for (int i = 0; i < n; i++) {
            accesses[i] = new AtomicInteger();
            accesses[i].set(0);
        }
    }

    public void lock(int i){
        for(int L = 1; L < n; L++){
            level[i].set(L);
            victim[L].set(i);
            while(whileCheck(i, L)){}
            accesses[i].set(accesses[i].get() + 1);
        }
    }
    public void unlock(int i){
        level[i].set(0);
    }


    public boolean whileCheck(int i, int L){
        boolean isVictim = victim[L].get() == i;
        if(!isVictim) return false;

        for (int k = 0; k < n; k++) {
            if(k != i && level[k].get() > L || (level[k].get() == L && accesses[k].get() < accesses[i].get()) ) return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Fair Peterson Lock";
    }
}

