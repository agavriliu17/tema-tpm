package org.internal;

public interface MyLock {
    public void lock(int i);
    public void unlock(int i);
}
