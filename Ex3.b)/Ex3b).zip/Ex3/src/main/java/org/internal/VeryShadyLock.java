package org.internal;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class VeryShadyLock implements Lock{
    public VeryShadyLock(ReentrantLock lock){
        this.lock = lock;
    }
    private ReentrantLock lock;
    private int x, y = 0;

    public void lock() {
        int me = ThreadId.get();
        x = me;
        while (y != 0) {};
        y = me;
        if (x != me) {
            lock.lock();
        }
    }

    @Override
    public void lockInterruptibly() throws InterruptedException {

    }

    @Override
    public boolean tryLock() {
        return false;
    }

    @Override
    public boolean tryLock(long time, TimeUnit unit) throws InterruptedException {
        return false;
    }

    public void unlock() {
        y = 0;
        if(lock.isHeldByCurrentThread()){
            lock.unlock();
        }
    }

    @Override
    public Condition newCondition() {
        return null;
    }
}
