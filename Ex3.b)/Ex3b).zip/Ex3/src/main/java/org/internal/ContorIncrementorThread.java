package org.internal;

import java.util.concurrent.locks.Lock;

public class ContorIncrementorThread extends Thread {
    private final Contor contor;
    private final int[] accessTable;
    private final int threadIndex;
    private final Lock lock;

    public ContorIncrementorThread(Contor contor, int[] accessTable, int threadIndex, Lock lock){
        this.contor = contor;
        this.accessTable = accessTable;
        this.threadIndex = threadIndex;
        this.lock = lock;
    }
    @Override
    public void run(){
        while(true){
            lock.lock();
            if(contor.x >= 3000){
                lock.unlock();
                break;
            }
            contor.x += 1;
            lock.unlock();
            this.accessTable[threadIndex] += 1;
        }
    }
}
