package org.internal;

public class Contor {
    volatile public int x = 0;
}